package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.dao.userrepository;
import com.example.demo.model.User;

@SpringBootApplication
 public class SpringbootAppApplication implements CommandLineRunner {



	public static void main(String[] args) {
		SpringApplication.run(SpringbootAppApplication.class, args);
	}
	@Autowired
	userrepository userRepo;

	@Override
	public void run(String... args) throws Exception {
		this.userRepo.save(new User("naveenkumar","S", "navviv.5035@gamil.com"));
		this.userRepo.save(new User("Vishnav","V", "Vishnav.v@gamil.com"));
		this.userRepo.save(new User("Rahul","Abhi", "rahul@gamil.com"));
		this.userRepo.save(new User("Nithish","Babu", "nithish.babu@gamil.com"));
		this.userRepo.save(new User("Deepauk","Sharath", "sharath@gamil.com"));
		this.userRepo.save(new User("Abhishek","Guru", "abhiguru@gamil.com"));
		
	}

}
