import logo from './logo.svg';
import './App.css';
import ListEmployee from './ListEmployee';

function App() {
  return (
    <div>
      <ListEmployee />
    </div>
  );
}

export default App;
